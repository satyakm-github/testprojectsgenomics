package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

/**
 * 
 * This is to create WebDriver object and set the WebDriver property. If the
 * driver is null it sets the WebDriver property else the same driver will
 * retain.
 * 
 * 
 * @author SatyaKeerthi.Manda
 *
 */
public class BaseClass {
	static public WebDriver driver;

	public BaseClass() {
		driver = getdriver();
	}

	public WebDriver getdriver() {
		if (driver == null) {
			String userdir = System.getProperty("user.dir");
			System.setProperty("webdriver.chrome.driver", userdir + "/src/test/resources/drivers/chromedriver.exe");
			driver = new ChromeDriver();
			return driver;
		} else {
			return driver;
		}
	}
}
