package pages;

import java.util.List;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

/**
 * 
 * This is to create WebElement locators for adding products to cart and
 * respective methods.
 * 
 * @author SatyaKeerthi.Manda
 *
 */
public class AddProductsToCartPage {

	WebDriver driver;

	@FindBy(xpath = "//input[@name='search']")
	WebElement txt_search;

	@FindBy(xpath = "//div[@class='input-group-button']/button")
	WebElement btn_search;

	@FindBy(xpath = "//button[contains(text(),'Load More')]")
	WebElement btn_loadMore;

	@FindBy(xpath = "*//div[@class='product-card-module_title-wrapper_1sj9D']")
	List<WebElement> allProducts;

	@FindBy(xpath = ".//a[@class='product-card-module_title-link_35kGk']/h4/span[1]/span[1]")
	WebElement webele_productsParentEle;

	@FindBy(xpath = ".//a[@class='product-card-module_title-link_35kGk']")
	WebElement webele_productsChildEle;

	@FindBy(xpath = "//div[@class='buybox-actions-container buybox-module_buybox-actions_2g4b2']/div/div/div[2]/button")
	WebElement btn_addProductToCart;

	public AddProductsToCartPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public void searchProducts(String searchProducts) {
		txt_search.sendKeys(searchProducts);
	}

	public void clickSearch() {
		btn_search.click();
	}

	public void clickLoadMore() {
		btn_loadMore.click();
	}

	public List<WebElement> allProducts() {
		return allProducts;
	}

	public WebElement productsParentEle() {
		return webele_productsParentEle;
	}

	public WebElement productsChildEle() {
		return webele_productsChildEle;
	}

	public void addProductToCart() {
		btn_addProductToCart.click();
	}

}
