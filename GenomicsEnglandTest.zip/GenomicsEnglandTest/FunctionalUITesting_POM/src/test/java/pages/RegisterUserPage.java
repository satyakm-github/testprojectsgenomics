package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

/**
 * 
 * This is to create WebElement locators for registering a new user and
 * respective methods.
 * 
 * @author SatyaKeerthi.Manda
 *
 */
public class RegisterUserPage {

	WebDriver driver;

	@FindBy(linkText = "Register")
	WebElement link_register;

	@FindBy(id = "firstname")
	WebElement txt_firstName;

	@FindBy(id = "surname")
	WebElement txt_surName;

	@FindBy(id = "email")
	WebElement txt_email;

	@FindBy(id = "email2")
	WebElement txt_email2;

	@FindBy(id = "password")
	WebElement txt_password;

	@FindBy(id = "password2")
	WebElement txt_password2;

	@FindBy(id = "telno1")
	WebElement txt_telno;

	@FindBy(xpath = "//input[@type='submit']")
	WebElement btn_registerNow;

	@FindBy(id = "welcome")
	WebElement win_welcome;

	public RegisterUserPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public void clickOnRegisterLink() {
		link_register.click();
	}

	public void registerUser(String firstName, String surname, String email, String email2, String password,
			String password2, String telno) {
		txt_firstName.sendKeys(firstName);
		txt_surName.sendKeys(surname);
		txt_email.sendKeys(email);
		txt_email2.sendKeys(email2);
		txt_password.sendKeys(password);
		txt_password2.sendKeys(password2);
		txt_telno.sendKeys(telno);
	}

	public void clickOnRegisterNow() {
		btn_registerNow.click();
	}

	public void clickOnWelcomeWindow() {
		win_welcome.click();
	}

}
