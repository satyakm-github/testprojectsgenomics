package pages;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

/**
 * 
 * This is to create WebElement locators for Validating the items in the
 * Shopping Cart and respective methods.
 * 
 * @author SatyaKeerthi.Manda
 *
 */
public class ValidateTheCartPage {
	WebDriver driver;

	@FindBy(xpath = "//div[@class='mini-cart mini-cart-module_mini-cart_3_CNC']/div/button")
	WebElement link_viewShoppingCart;

	@FindBy(xpath = "*//h3[@class='cart-item-module_item-title_1M9cq']")
	List<WebElement> list_cartItems;

	public WebElement viewShoppingCart() {
		return link_viewShoppingCart;
	}

	public List<WebElement> cartItems() {
		return list_cartItems;
	}

	public ValidateTheCartPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
}
