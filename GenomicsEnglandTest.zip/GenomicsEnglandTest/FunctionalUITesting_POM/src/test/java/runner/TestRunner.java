package runner;

import org.junit.runner.RunWith;
import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

/**
 * 
 * This TestRunner class is to set the feature files & step definitions path and
 * also specify the type of reports to be generated for the test results
 * 
 * @author SatyaKeerthi.Manda
 *
 */
@RunWith(Cucumber.class)
@CucumberOptions(features = { "src/test/resources/Features/01_registeruser.feature",
		"src/test/resources/Features/02_addproductstocart.feature",
		"src/test/resources/Features/03_validatethecart.feature" }, glue = { "steps" }, monochrome = true, plugin = {
				"pretty", "junit:target/JUnitReports/report.xml", "html:target/HtmlReports/report.html",
				"json:target/JsonReports/report.json" })
public class TestRunner {

}