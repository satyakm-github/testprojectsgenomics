package steps;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.AddProductsToCartPage;
import pages.BaseClass;

/**
 * 
 * This AddProductsToCartSteps StepDefinition search for products in "takealot.com" and adds the
 * specified products to shopping cart.
 * 
 * @author SatyaKeerthi.Manda
 *
 */
public class AddProductsToCartSteps extends BaseClass {
	AddProductsToCartPage addProductsToCartPage;

	@When("user search for products")
	public void user_search_for_products(String searchProducts) {
		addProductsToCartPage = new AddProductsToCartPage(driver);
		addProductsToCartPage.searchProducts(searchProducts);
		addProductsToCartPage.clickSearch();
	}

	@Then("user selects a product")
	public void user_selects_a_product(String prodToSearch) {
		System.out.println("*** Trying to add the product: " + prodToSearch);

		WebDriverWait explicitWait = new WebDriverWait(driver, 10);
		explicitWait.until(
				ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[contains(text(),'Load More')]")));

		boolean atleastOneProdFound = false;

		while (atleastOneProdFound == false) {
			List<WebElement> allProdInGivenPage = addProductsToCartPage.allProducts();

			System.out.println("Number of products in this page: " + allProdInGivenPage.size());

			for (WebElement eachProduct : allProdInGivenPage) {
				// could have done 'contains' as well but seems tricky.
				WebElement prodNameElem = eachProduct.findElement(
						By.xpath(".//a[@class='product-card-module_title-link_35kGk']/h4/span[1]/span[1]"));
				String eachProdName = prodNameElem.getText();

				boolean lengthyProd = false;
				if (eachProdName.endsWith("…")) {
					if (prodToSearch.indexOf(eachProdName.replaceAll("…", "")) != -1) {
						lengthyProd = true;
					}
				}

				if (eachProdName.equalsIgnoreCase(prodToSearch) || lengthyProd == true) {
					System.out.println("========> Hurray! Product found : " + eachProdName);
					WebElement parentAElem = eachProduct
							.findElement(By.xpath(".//a[@class='product-card-module_title-link_35kGk']"));
					String prodURL = parentAElem.getAttribute("href");
					driver.navigate().to(prodURL);
					return;
				}
			}
			addProductsToCartPage.clickLoadMore();
			explicitWait = new WebDriverWait(driver, 15);
		}
	}

	@Then("user adds selected product to the cart")
	public void user_adds_selected_product_to_the_cart() {
		WebDriverWait explicitWait = new WebDriverWait(driver, 15);
		explicitWait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(
				"//div[@class='buybox-actions-container buybox-module_buybox-actions_2g4b2']/div/div/div[2]/button")));

		addProductsToCartPage.addProductToCart();
	}

}
