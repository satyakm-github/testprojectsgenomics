package steps;

import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import pages.BaseClass;
import pages.ValidateTheCartPage;

/**
 * 
 * This ValidateTheCartSteps StepDefinition, validates the items in the Shopping
 * are same as the one's selected by the user
 * 
 * @author SatyaKeerthi.Manda
 *
 */

public class ValidateTheCartSteps extends BaseClass {
	ValidateTheCartPage validateTheCartPage;

	@Given("user is in Shopping Cart")
	public void user_clicks_on_Shopping_Cart() {
		validateTheCartPage = new ValidateTheCartPage(driver);
		WebElement shoppingCart = validateTheCartPage.viewShoppingCart();
		shoppingCart.click();
	}

	@Then("^user should have following in the cart$")
	public void user_should_have_following(List<String> prodsInCart) throws Throwable {
		System.out.println(prodsInCart);

		WebDriverWait explicitWait = new WebDriverWait(driver, 10);
		explicitWait.until(ExpectedConditions
				.visibilityOfElementLocated(By.xpath("*//h3[@class='cart-item-module_item-title_1M9cq']")));
		if (prodsInCart != null && prodsInCart.size() > 0) {
			int totalNumOfProdToCheck = prodsInCart.size();
			int count = 0;
			List<WebElement> allProdsInCart = validateTheCartPage.cartItems();

			System.out.println("Total numbers of products in the cart : " + allProdsInCart.size());

			for (WebElement eachProd : allProdsInCart) {
				System.out.println("Comparing this cart Item (with passed in inputs) : " + eachProd.getText());
				if (prodsInCart.contains(eachProd.getText())) {
					count++;
				}
			}
			if (count == totalNumOfProdToCheck) {
				System.out.println();
				System.out.println("********** Success **********");
				System.out.println();
			} else {
				System.out.println();
				System.out.println("********** Failure **********");
				System.out.println();
			}
			Assert.assertEquals(totalNumOfProdToCheck, count);
		}
	}

	@Then("user quit the browser")
	public void user_quit_the_browser() {
		driver.quit();
	}
}
