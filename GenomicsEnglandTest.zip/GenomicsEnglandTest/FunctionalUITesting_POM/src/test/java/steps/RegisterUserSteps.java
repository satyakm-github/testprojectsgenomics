package steps;

import java.text.SimpleDateFormat;
import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.BaseClass;
import pages.RegisterUserPage;

/**
 * 
 * This RegisterUserSteps StepDefinition registers a new user in "takealot.com"
 * and verifies the welcome message.
 * 
 * @author SatyaKeerthi.Manda
 *
 */
public class RegisterUserSteps extends BaseClass {
	RegisterUserPage registerUserPage;

	@Given("user is on takealot.com")
	public void user_is_on_takealot_com() {
		driver.get("https://www.takealot.com/");
		driver.manage().window().maximize();
		// TODO : remove hard coded waits in each method
		WebDriverWait explicitWait = new WebDriverWait(driver, 8);
		explicitWait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("Register")));
	}

	@When("user clicks on register link")
	public void user_clicks_on_register_link() {
		registerUserPage = new RegisterUserPage(driver);
		registerUserPage.clickOnRegisterLink();
		WebDriverWait explicitWait = new WebDriverWait(driver, 8);
		explicitWait.until(ExpectedConditions.visibilityOfElementLocated(By.id("firstname")));
	}

	@Then("user enters all the details to register a new user")
	public void user_enters_all_the_details_to_register_a_new_user(List<String> inputs) {
		String firstName = inputs.get(0);
		String surName = inputs.get(1);
		String email = inputs.get(2);
		String email2 = inputs.get(3);
		String password = inputs.get(4);
		String password2 = inputs.get(5);
		String telno = inputs.get(6);

		// Generates a timestamp to give unique users
		String timeStampString = new SimpleDateFormat("HHmmss_yyyyMMdd").format(new java.util.Date());

		registerUserPage.registerUser(firstName + timeStampString, surName + timeStampString,
				email + timeStampString + "@gmail.com", email2 + timeStampString + "@gmail.com", password, password2,
				telno);
	}

	@And("user clicks on Register Now button")
	public void user_clicks_on_register_now_button() {
		registerUserPage.clickOnRegisterNow();
		long timeOutInSecs = 8;
		WebDriverWait explicitWait = new WebDriverWait(driver, timeOutInSecs);
		explicitWait.until(ExpectedConditions.visibilityOfElementLocated(By.id("welcome")));
	}

	@Then("user clicks on the welcome window")
	public void user_clicks_on_the_welcome_window() throws InterruptedException {
		String registerUrl = driver.getCurrentUrl();
		Assert.assertEquals("https://secure.takealot.com/account/register", registerUrl);
		registerUserPage.clickOnWelcomeWindow();
		WebDriverWait explicitWait = new WebDriverWait(driver, 8);
		explicitWait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@name='search']")));
	}

}
