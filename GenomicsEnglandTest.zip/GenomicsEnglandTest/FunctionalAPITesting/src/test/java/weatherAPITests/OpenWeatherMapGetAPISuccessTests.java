package weatherAPITests;

import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

import org.apache.http.HttpStatus;
import org.testng.annotations.Test;

public class OpenWeatherMapGetAPISuccessTests extends OpenWeatherConf {
	private final static String CNTN_TYPE_APPL_JSON = "application/json; charset=utf-8";

	/**
	 * This method fires a GET request on current weather API, for a location and
	 * and validates the response status code and asserts the response body.
	 */
	@Test
	public void getWeatherDetails_SuccessReq() {
		given().when().get(uri + "q=London,uk&appid=" + appId).then().statusCode(HttpStatus.SC_OK).assertThat()
				.body("name", equalTo("London")).header("Content-Type", CNTN_TYPE_APPL_JSON);
		// .log().all();
	}

	/**
	 * This method fires a GET request on current weather API, by passing the appId
	 * & location as params and validates the response status code and asserts the
	 * response body.
	 */
	@Test
	public void getWeatherDetails_SuccessReq_WitParams() {
		given().param("appid", appId).param("q", "London,uk")
				// .header(arg0)
				.when().get(uriSimple).then().statusCode(HttpStatus.SC_OK).assertThat().body("name", equalTo("London"))
				.header("Content-Type", CNTN_TYPE_APPL_JSON);
	}

	/**
	 * This method fires a GET request for current weather API, by Country and
	 * validates the response status code and asserts the response body.
	 */
	@Test
	public void getWeatherDetails_SuccessReq_getCountry() {
		when().get(uri + "q=London,uk&appid=" + appId).then().statusCode(HttpStatus.SC_OK).assertThat()
				.body("sys.country", equalTo("GB")).header("Content-Type", CNTN_TYPE_APPL_JSON);
	}

	/**
	 * This method fires a GET request on current weather by
	 * CityNameCountryCodeStateCode and validates the response status code and
	 * asserts the response body.
	 */
	@Test
	public void getWeatherDetails_ByCityNameCountryCodeStateCode() {
		when().get(uri + "q=New York,36,+1&appid=" + appId).then().statusCode(HttpStatus.SC_OK).assertThat()
				.body("name", equalTo("New York")).header("Content-Type", CNTN_TYPE_APPL_JSON);
	}

	/**
	 * This method fires a GET request on current weather by Longitude & Latitude
	 * and validates the response status code and asserts the response body.
	 */
	@Test
	public void getWeatherDetails_ByLonLat() {
		when().get(uri + "lat=35&lon=139&appid=" + appId).then().statusCode(HttpStatus.SC_OK).assertThat()
				.body("name", equalTo("Shuzenji")).header("Content-Type", CNTN_TYPE_APPL_JSON);

	}

	/**
	 * This method fires a GET request on current weather by ZipCode and validates
	 * the response status code and asserts the response body.
	 */

	@Test
	public void getWeatherDetails_ByZipCode() {
		when().get(uri + "zip=94040,us&appid=" + appId).then().statusCode(HttpStatus.SC_OK).assertThat()
				.body("name", equalTo("Mountain View")).header("Content-Type", CNTN_TYPE_APPL_JSON);
	}

}
