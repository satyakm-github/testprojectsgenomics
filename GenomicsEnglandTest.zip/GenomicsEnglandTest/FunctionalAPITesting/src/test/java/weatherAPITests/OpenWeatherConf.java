package weatherAPITests;

/**
 * This is a config class to set the static values of GET request api uri & APP
 * Key, which are used in subclasses
 * 
 */
public class OpenWeatherConf {
	// Ideally the below values could be read from a properties file
	public String appId = "489830a32c5d8ac40ed32c2911a9cf2f";
	public String uriSimple = "http://api.openweathermap.org/data/2.5/weather";
	public String uri = uriSimple + "?";

	public OpenWeatherConf() {
	}
}
