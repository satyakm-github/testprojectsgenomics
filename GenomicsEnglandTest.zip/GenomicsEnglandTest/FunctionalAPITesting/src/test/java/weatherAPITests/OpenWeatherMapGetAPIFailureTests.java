package weatherAPITests;

import static io.restassured.RestAssured.when;
import static org.hamcrest.Matchers.equalTo;

import org.apache.http.HttpStatus;
import org.testng.annotations.Test;

public class OpenWeatherMapGetAPIFailureTests extends OpenWeatherConf {
	private final static String CNTN_TYPE_APPL_JSON = "application/json; charset=utf-8";

	/**
	 * This method fires a GET request on current weather API with incorrect APP
	 * Key, to validate the the response status code and asserts the response body.
	 */
	@Test
	public void getWeatherDetails_UnauthorisedReq() {
		when().get(uri + "q=London,uk&appid=" + appId + "wr").then().statusCode(HttpStatus.SC_UNAUTHORIZED).assertThat()
				.body("message",
						equalTo("Invalid API key. Please see http://openweathermap.org/faq#error401 for more info."))
				.header("Content-Type", CNTN_TYPE_APPL_JSON);
	}

	/**
	 * This method fires a GET request on current weather API with incorrect param
	 * value to validate the the response status code and asserts the response body.
	 */
	@Test
	public void getWeatherDetails_NotFoundReq() {
		when().get(uri + "q=Londons,uk&appid=" + appId).then().statusCode(HttpStatus.SC_NOT_FOUND).assertThat()
				.body("message", equalTo("city not found")).body("cod", equalTo("404"))
				.header("Content-Type", CNTN_TYPE_APPL_JSON);
	}

}
